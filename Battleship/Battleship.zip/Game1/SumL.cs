﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1
{
    internal class SumL
    {
        public int number { get; set; }

        public SumL(int number)
        {
            this.number = number;
        }
    }
}
