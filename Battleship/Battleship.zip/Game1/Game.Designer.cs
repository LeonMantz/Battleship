﻿namespace Game1
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.button00 = new System.Windows.Forms.Button();
            this.button01 = new System.Windows.Forms.Button();
            this.button02 = new System.Windows.Forms.Button();
            this.button03 = new System.Windows.Forms.Button();
            this.button04 = new System.Windows.Forms.Button();
            this.button05 = new System.Windows.Forms.Button();
            this.button06 = new System.Windows.Forms.Button();
            this.button07 = new System.Windows.Forms.Button();
            this.button08 = new System.Windows.Forms.Button();
            this.button09 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.button04E = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.button00E = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.button01E = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button02E = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.button03E = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.button05E = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.button06E = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.button07E = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.button08E = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.button09E = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.button10E = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button11E = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.button12E = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.button13E = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.button14E = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.button15E = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.button16E = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.button17E = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.button18E = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.button19E = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.button20E = new System.Windows.Forms.Button();
            this.button99E = new System.Windows.Forms.Button();
            this.button21E = new System.Windows.Forms.Button();
            this.button98E = new System.Windows.Forms.Button();
            this.button22E = new System.Windows.Forms.Button();
            this.button97E = new System.Windows.Forms.Button();
            this.button23E = new System.Windows.Forms.Button();
            this.button96E = new System.Windows.Forms.Button();
            this.button24E = new System.Windows.Forms.Button();
            this.button95E = new System.Windows.Forms.Button();
            this.button25E = new System.Windows.Forms.Button();
            this.button94E = new System.Windows.Forms.Button();
            this.button26E = new System.Windows.Forms.Button();
            this.button93E = new System.Windows.Forms.Button();
            this.button27E = new System.Windows.Forms.Button();
            this.button92E = new System.Windows.Forms.Button();
            this.button28E = new System.Windows.Forms.Button();
            this.button91E = new System.Windows.Forms.Button();
            this.button29E = new System.Windows.Forms.Button();
            this.button90E = new System.Windows.Forms.Button();
            this.button30E = new System.Windows.Forms.Button();
            this.button89E = new System.Windows.Forms.Button();
            this.button31E = new System.Windows.Forms.Button();
            this.button88E = new System.Windows.Forms.Button();
            this.button32E = new System.Windows.Forms.Button();
            this.button87E = new System.Windows.Forms.Button();
            this.button33E = new System.Windows.Forms.Button();
            this.button86E = new System.Windows.Forms.Button();
            this.button34E = new System.Windows.Forms.Button();
            this.button85E = new System.Windows.Forms.Button();
            this.button35E = new System.Windows.Forms.Button();
            this.button84E = new System.Windows.Forms.Button();
            this.button36E = new System.Windows.Forms.Button();
            this.button83E = new System.Windows.Forms.Button();
            this.button37E = new System.Windows.Forms.Button();
            this.button82E = new System.Windows.Forms.Button();
            this.button38E = new System.Windows.Forms.Button();
            this.button81E = new System.Windows.Forms.Button();
            this.button39E = new System.Windows.Forms.Button();
            this.button80E = new System.Windows.Forms.Button();
            this.button40E = new System.Windows.Forms.Button();
            this.button79E = new System.Windows.Forms.Button();
            this.button41E = new System.Windows.Forms.Button();
            this.button78E = new System.Windows.Forms.Button();
            this.button42E = new System.Windows.Forms.Button();
            this.button77E = new System.Windows.Forms.Button();
            this.button43E = new System.Windows.Forms.Button();
            this.button76E = new System.Windows.Forms.Button();
            this.button44E = new System.Windows.Forms.Button();
            this.button75E = new System.Windows.Forms.Button();
            this.button45E = new System.Windows.Forms.Button();
            this.button74E = new System.Windows.Forms.Button();
            this.button46E = new System.Windows.Forms.Button();
            this.button73E = new System.Windows.Forms.Button();
            this.button47E = new System.Windows.Forms.Button();
            this.button72E = new System.Windows.Forms.Button();
            this.button48E = new System.Windows.Forms.Button();
            this.button71E = new System.Windows.Forms.Button();
            this.button49E = new System.Windows.Forms.Button();
            this.button70E = new System.Windows.Forms.Button();
            this.button50E = new System.Windows.Forms.Button();
            this.button69E = new System.Windows.Forms.Button();
            this.button51E = new System.Windows.Forms.Button();
            this.button68E = new System.Windows.Forms.Button();
            this.button52E = new System.Windows.Forms.Button();
            this.button67E = new System.Windows.Forms.Button();
            this.button53E = new System.Windows.Forms.Button();
            this.button66E = new System.Windows.Forms.Button();
            this.button54E = new System.Windows.Forms.Button();
            this.button65E = new System.Windows.Forms.Button();
            this.button55E = new System.Windows.Forms.Button();
            this.button64E = new System.Windows.Forms.Button();
            this.button56E = new System.Windows.Forms.Button();
            this.button63E = new System.Windows.Forms.Button();
            this.button57E = new System.Windows.Forms.Button();
            this.button62E = new System.Windows.Forms.Button();
            this.button58E = new System.Windows.Forms.Button();
            this.button61E = new System.Windows.Forms.Button();
            this.button59E = new System.Windows.Forms.Button();
            this.button60E = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button00
            // 
            this.button00.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button00.Location = new System.Drawing.Point(98, 48);
            this.button00.Name = "button00";
            this.button00.Size = new System.Drawing.Size(32, 32);
            this.button00.TabIndex = 0;
            this.button00.UseVisualStyleBackColor = true;
            this.button00.Click += new System.EventHandler(this.button_Click);
            // 
            // button01
            // 
            this.button01.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button01.Location = new System.Drawing.Point(136, 48);
            this.button01.Name = "button01";
            this.button01.Size = new System.Drawing.Size(32, 32);
            this.button01.TabIndex = 1;
            this.button01.UseVisualStyleBackColor = true;
            this.button01.Click += new System.EventHandler(this.button_Click);
            // 
            // button02
            // 
            this.button02.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button02.Location = new System.Drawing.Point(174, 48);
            this.button02.Name = "button02";
            this.button02.Size = new System.Drawing.Size(32, 32);
            this.button02.TabIndex = 2;
            this.button02.UseVisualStyleBackColor = true;
            this.button02.Click += new System.EventHandler(this.button_Click);
            // 
            // button03
            // 
            this.button03.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button03.Location = new System.Drawing.Point(212, 48);
            this.button03.Name = "button03";
            this.button03.Size = new System.Drawing.Size(32, 32);
            this.button03.TabIndex = 3;
            this.button03.UseVisualStyleBackColor = true;
            this.button03.Click += new System.EventHandler(this.button_Click);
            // 
            // button04
            // 
            this.button04.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button04.Location = new System.Drawing.Point(250, 48);
            this.button04.Name = "button04";
            this.button04.Size = new System.Drawing.Size(32, 32);
            this.button04.TabIndex = 4;
            this.button04.UseVisualStyleBackColor = true;
            this.button04.Click += new System.EventHandler(this.button_Click);
            // 
            // button05
            // 
            this.button05.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button05.Location = new System.Drawing.Point(288, 48);
            this.button05.Name = "button05";
            this.button05.Size = new System.Drawing.Size(32, 32);
            this.button05.TabIndex = 5;
            this.button05.UseVisualStyleBackColor = true;
            this.button05.Click += new System.EventHandler(this.button_Click);
            // 
            // button06
            // 
            this.button06.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button06.Location = new System.Drawing.Point(326, 48);
            this.button06.Name = "button06";
            this.button06.Size = new System.Drawing.Size(32, 32);
            this.button06.TabIndex = 6;
            this.button06.UseVisualStyleBackColor = true;
            this.button06.Click += new System.EventHandler(this.button_Click);
            // 
            // button07
            // 
            this.button07.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button07.Location = new System.Drawing.Point(364, 48);
            this.button07.Name = "button07";
            this.button07.Size = new System.Drawing.Size(32, 32);
            this.button07.TabIndex = 7;
            this.button07.UseVisualStyleBackColor = true;
            this.button07.Click += new System.EventHandler(this.button_Click);
            // 
            // button08
            // 
            this.button08.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button08.Location = new System.Drawing.Point(402, 48);
            this.button08.Name = "button08";
            this.button08.Size = new System.Drawing.Size(32, 32);
            this.button08.TabIndex = 8;
            this.button08.UseVisualStyleBackColor = true;
            this.button08.Click += new System.EventHandler(this.button_Click);
            // 
            // button09
            // 
            this.button09.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button09.Location = new System.Drawing.Point(440, 49);
            this.button09.Name = "button09";
            this.button09.Size = new System.Drawing.Size(32, 32);
            this.button09.TabIndex = 9;
            this.button09.UseVisualStyleBackColor = true;
            this.button09.Click += new System.EventHandler(this.button_Click);
            // 
            // button19
            // 
            this.button19.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button19.Location = new System.Drawing.Point(440, 86);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(32, 32);
            this.button19.TabIndex = 19;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button_Click);
            // 
            // button18
            // 
            this.button18.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button18.Location = new System.Drawing.Point(402, 86);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(32, 32);
            this.button18.TabIndex = 18;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button_Click);
            // 
            // button17
            // 
            this.button17.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button17.Location = new System.Drawing.Point(364, 86);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(32, 32);
            this.button17.TabIndex = 17;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button_Click);
            // 
            // button16
            // 
            this.button16.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button16.Location = new System.Drawing.Point(326, 86);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(32, 32);
            this.button16.TabIndex = 16;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button_Click);
            // 
            // button15
            // 
            this.button15.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button15.Location = new System.Drawing.Point(288, 86);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(32, 32);
            this.button15.TabIndex = 15;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button_Click);
            // 
            // button14
            // 
            this.button14.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button14.Location = new System.Drawing.Point(250, 86);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(32, 32);
            this.button14.TabIndex = 14;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button_Click);
            // 
            // button13
            // 
            this.button13.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button13.Location = new System.Drawing.Point(212, 86);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(32, 32);
            this.button13.TabIndex = 13;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button_Click);
            // 
            // button12
            // 
            this.button12.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button12.Location = new System.Drawing.Point(174, 86);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(32, 32);
            this.button12.TabIndex = 12;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button_Click);
            // 
            // button11
            // 
            this.button11.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button11.Location = new System.Drawing.Point(136, 86);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(32, 32);
            this.button11.TabIndex = 11;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button_Click);
            // 
            // button10
            // 
            this.button10.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button10.Location = new System.Drawing.Point(98, 86);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(32, 32);
            this.button10.TabIndex = 10;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button_Click);
            // 
            // button29
            // 
            this.button29.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button29.Location = new System.Drawing.Point(440, 124);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(32, 32);
            this.button29.TabIndex = 29;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button_Click);
            // 
            // button28
            // 
            this.button28.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button28.Location = new System.Drawing.Point(402, 124);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(32, 32);
            this.button28.TabIndex = 28;
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button_Click);
            // 
            // button27
            // 
            this.button27.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button27.Location = new System.Drawing.Point(364, 124);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(32, 32);
            this.button27.TabIndex = 27;
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button_Click);
            // 
            // button26
            // 
            this.button26.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button26.Location = new System.Drawing.Point(326, 124);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(32, 32);
            this.button26.TabIndex = 26;
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button_Click);
            // 
            // button25
            // 
            this.button25.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button25.Location = new System.Drawing.Point(288, 124);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(32, 32);
            this.button25.TabIndex = 25;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button_Click);
            // 
            // button24
            // 
            this.button24.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button24.Location = new System.Drawing.Point(250, 124);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(32, 32);
            this.button24.TabIndex = 24;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button_Click);
            // 
            // button23
            // 
            this.button23.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button23.Location = new System.Drawing.Point(212, 124);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(32, 32);
            this.button23.TabIndex = 23;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button_Click);
            // 
            // button22
            // 
            this.button22.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button22.Location = new System.Drawing.Point(174, 124);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(32, 32);
            this.button22.TabIndex = 22;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button_Click);
            // 
            // button21
            // 
            this.button21.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button21.Location = new System.Drawing.Point(136, 124);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(32, 32);
            this.button21.TabIndex = 21;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button_Click);
            // 
            // button20
            // 
            this.button20.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button20.Location = new System.Drawing.Point(98, 124);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(32, 32);
            this.button20.TabIndex = 20;
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button_Click);
            // 
            // button39
            // 
            this.button39.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button39.Location = new System.Drawing.Point(440, 162);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(32, 32);
            this.button39.TabIndex = 39;
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button_Click);
            // 
            // button38
            // 
            this.button38.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button38.Location = new System.Drawing.Point(402, 162);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(32, 32);
            this.button38.TabIndex = 38;
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button_Click);
            // 
            // button37
            // 
            this.button37.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button37.Location = new System.Drawing.Point(364, 162);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(32, 32);
            this.button37.TabIndex = 37;
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button_Click);
            // 
            // button36
            // 
            this.button36.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button36.Location = new System.Drawing.Point(326, 162);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(32, 32);
            this.button36.TabIndex = 36;
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button_Click);
            // 
            // button35
            // 
            this.button35.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button35.Location = new System.Drawing.Point(288, 162);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(32, 32);
            this.button35.TabIndex = 35;
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button_Click);
            // 
            // button34
            // 
            this.button34.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button34.Location = new System.Drawing.Point(250, 162);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(32, 32);
            this.button34.TabIndex = 34;
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button_Click);
            // 
            // button33
            // 
            this.button33.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button33.Location = new System.Drawing.Point(212, 162);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(32, 32);
            this.button33.TabIndex = 33;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button_Click);
            // 
            // button32
            // 
            this.button32.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button32.Location = new System.Drawing.Point(174, 162);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(32, 32);
            this.button32.TabIndex = 32;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button_Click);
            // 
            // button31
            // 
            this.button31.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button31.Location = new System.Drawing.Point(136, 162);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(32, 32);
            this.button31.TabIndex = 31;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button_Click);
            // 
            // button30
            // 
            this.button30.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button30.Location = new System.Drawing.Point(98, 162);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(32, 32);
            this.button30.TabIndex = 30;
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button_Click);
            // 
            // button49
            // 
            this.button49.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button49.Location = new System.Drawing.Point(440, 200);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(32, 32);
            this.button49.TabIndex = 49;
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button_Click);
            // 
            // button48
            // 
            this.button48.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button48.Location = new System.Drawing.Point(402, 200);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(32, 32);
            this.button48.TabIndex = 48;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button_Click);
            // 
            // button47
            // 
            this.button47.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button47.Location = new System.Drawing.Point(364, 200);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(32, 32);
            this.button47.TabIndex = 47;
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button_Click);
            // 
            // button46
            // 
            this.button46.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button46.Location = new System.Drawing.Point(326, 200);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(32, 32);
            this.button46.TabIndex = 46;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button_Click);
            // 
            // button45
            // 
            this.button45.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button45.Location = new System.Drawing.Point(288, 200);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(32, 32);
            this.button45.TabIndex = 45;
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button_Click);
            // 
            // button44
            // 
            this.button44.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button44.Location = new System.Drawing.Point(250, 200);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(32, 32);
            this.button44.TabIndex = 44;
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button_Click);
            // 
            // button43
            // 
            this.button43.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button43.Location = new System.Drawing.Point(212, 200);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(32, 32);
            this.button43.TabIndex = 43;
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button_Click);
            // 
            // button42
            // 
            this.button42.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button42.Location = new System.Drawing.Point(174, 200);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(32, 32);
            this.button42.TabIndex = 42;
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button_Click);
            // 
            // button41
            // 
            this.button41.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button41.Location = new System.Drawing.Point(136, 200);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(32, 32);
            this.button41.TabIndex = 41;
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button_Click);
            // 
            // button40
            // 
            this.button40.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button40.Location = new System.Drawing.Point(98, 200);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(32, 32);
            this.button40.TabIndex = 40;
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button_Click);
            // 
            // button59
            // 
            this.button59.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button59.Location = new System.Drawing.Point(440, 238);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(32, 32);
            this.button59.TabIndex = 59;
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button_Click);
            // 
            // button58
            // 
            this.button58.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button58.Location = new System.Drawing.Point(402, 238);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(32, 32);
            this.button58.TabIndex = 58;
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button_Click);
            // 
            // button57
            // 
            this.button57.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button57.Location = new System.Drawing.Point(364, 238);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(32, 32);
            this.button57.TabIndex = 57;
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button_Click);
            // 
            // button56
            // 
            this.button56.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button56.Location = new System.Drawing.Point(326, 238);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(32, 32);
            this.button56.TabIndex = 56;
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button_Click);
            // 
            // button55
            // 
            this.button55.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button55.Location = new System.Drawing.Point(288, 238);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(32, 32);
            this.button55.TabIndex = 55;
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button_Click);
            // 
            // button54
            // 
            this.button54.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button54.Location = new System.Drawing.Point(250, 238);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(32, 32);
            this.button54.TabIndex = 54;
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button_Click);
            // 
            // button53
            // 
            this.button53.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button53.Location = new System.Drawing.Point(212, 238);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(32, 32);
            this.button53.TabIndex = 53;
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button_Click);
            // 
            // button52
            // 
            this.button52.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button52.Location = new System.Drawing.Point(174, 238);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(32, 32);
            this.button52.TabIndex = 52;
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button_Click);
            // 
            // button51
            // 
            this.button51.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button51.Location = new System.Drawing.Point(136, 238);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(32, 32);
            this.button51.TabIndex = 51;
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button_Click);
            // 
            // button50
            // 
            this.button50.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button50.Location = new System.Drawing.Point(98, 238);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(32, 32);
            this.button50.TabIndex = 50;
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button_Click);
            // 
            // button69
            // 
            this.button69.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button69.Location = new System.Drawing.Point(440, 276);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(32, 32);
            this.button69.TabIndex = 69;
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button_Click);
            // 
            // button68
            // 
            this.button68.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button68.Location = new System.Drawing.Point(402, 276);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(32, 32);
            this.button68.TabIndex = 68;
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button_Click);
            // 
            // button67
            // 
            this.button67.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button67.Location = new System.Drawing.Point(364, 276);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(32, 32);
            this.button67.TabIndex = 67;
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button_Click);
            // 
            // button66
            // 
            this.button66.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button66.Location = new System.Drawing.Point(326, 276);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(32, 32);
            this.button66.TabIndex = 66;
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button_Click);
            // 
            // button65
            // 
            this.button65.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button65.Location = new System.Drawing.Point(288, 276);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(32, 32);
            this.button65.TabIndex = 65;
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button_Click);
            // 
            // button64
            // 
            this.button64.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button64.Location = new System.Drawing.Point(250, 276);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(32, 32);
            this.button64.TabIndex = 64;
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button_Click);
            // 
            // button63
            // 
            this.button63.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button63.Location = new System.Drawing.Point(212, 276);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(32, 32);
            this.button63.TabIndex = 63;
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button_Click);
            // 
            // button62
            // 
            this.button62.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button62.Location = new System.Drawing.Point(174, 276);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(32, 32);
            this.button62.TabIndex = 62;
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button_Click);
            // 
            // button61
            // 
            this.button61.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button61.Location = new System.Drawing.Point(136, 276);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(32, 32);
            this.button61.TabIndex = 61;
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button_Click);
            // 
            // button60
            // 
            this.button60.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button60.Location = new System.Drawing.Point(98, 276);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(32, 32);
            this.button60.TabIndex = 60;
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button_Click);
            // 
            // button79
            // 
            this.button79.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button79.Location = new System.Drawing.Point(440, 314);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(32, 32);
            this.button79.TabIndex = 79;
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.button_Click);
            // 
            // button78
            // 
            this.button78.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button78.Location = new System.Drawing.Point(402, 314);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(32, 32);
            this.button78.TabIndex = 78;
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button_Click);
            // 
            // button77
            // 
            this.button77.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button77.Location = new System.Drawing.Point(364, 314);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(32, 32);
            this.button77.TabIndex = 77;
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button_Click);
            // 
            // button76
            // 
            this.button76.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button76.Location = new System.Drawing.Point(326, 314);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(32, 32);
            this.button76.TabIndex = 76;
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button_Click);
            // 
            // button75
            // 
            this.button75.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button75.Location = new System.Drawing.Point(288, 314);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(32, 32);
            this.button75.TabIndex = 75;
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button_Click);
            // 
            // button74
            // 
            this.button74.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button74.Location = new System.Drawing.Point(250, 314);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(32, 32);
            this.button74.TabIndex = 74;
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button_Click);
            // 
            // button73
            // 
            this.button73.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button73.Location = new System.Drawing.Point(212, 314);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(32, 32);
            this.button73.TabIndex = 73;
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button_Click);
            // 
            // button72
            // 
            this.button72.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button72.Location = new System.Drawing.Point(174, 314);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(32, 32);
            this.button72.TabIndex = 72;
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button_Click);
            // 
            // button71
            // 
            this.button71.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button71.Location = new System.Drawing.Point(136, 314);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(32, 32);
            this.button71.TabIndex = 71;
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button_Click);
            // 
            // button70
            // 
            this.button70.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button70.Location = new System.Drawing.Point(98, 314);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(32, 32);
            this.button70.TabIndex = 70;
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button_Click);
            // 
            // button89
            // 
            this.button89.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button89.Location = new System.Drawing.Point(440, 352);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(32, 32);
            this.button89.TabIndex = 89;
            this.button89.UseVisualStyleBackColor = true;
            this.button89.Click += new System.EventHandler(this.button_Click);
            // 
            // button88
            // 
            this.button88.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button88.Location = new System.Drawing.Point(402, 352);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(32, 32);
            this.button88.TabIndex = 88;
            this.button88.UseVisualStyleBackColor = true;
            this.button88.Click += new System.EventHandler(this.button_Click);
            // 
            // button87
            // 
            this.button87.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button87.Location = new System.Drawing.Point(364, 352);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(32, 32);
            this.button87.TabIndex = 87;
            this.button87.UseVisualStyleBackColor = true;
            this.button87.Click += new System.EventHandler(this.button_Click);
            // 
            // button86
            // 
            this.button86.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button86.Location = new System.Drawing.Point(326, 352);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(32, 32);
            this.button86.TabIndex = 86;
            this.button86.UseVisualStyleBackColor = true;
            this.button86.Click += new System.EventHandler(this.button_Click);
            // 
            // button85
            // 
            this.button85.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button85.Location = new System.Drawing.Point(288, 352);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(32, 32);
            this.button85.TabIndex = 85;
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.button_Click);
            // 
            // button84
            // 
            this.button84.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button84.Location = new System.Drawing.Point(250, 352);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(32, 32);
            this.button84.TabIndex = 84;
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button_Click);
            // 
            // button83
            // 
            this.button83.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button83.Location = new System.Drawing.Point(212, 352);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(32, 32);
            this.button83.TabIndex = 83;
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.button_Click);
            // 
            // button82
            // 
            this.button82.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button82.Location = new System.Drawing.Point(174, 352);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(32, 32);
            this.button82.TabIndex = 82;
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button_Click);
            // 
            // button81
            // 
            this.button81.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button81.Location = new System.Drawing.Point(136, 352);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(32, 32);
            this.button81.TabIndex = 81;
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.button_Click);
            // 
            // button80
            // 
            this.button80.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button80.Location = new System.Drawing.Point(98, 352);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(32, 32);
            this.button80.TabIndex = 80;
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.button_Click);
            // 
            // button99
            // 
            this.button99.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button99.Location = new System.Drawing.Point(440, 390);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(32, 32);
            this.button99.TabIndex = 99;
            this.button99.UseVisualStyleBackColor = true;
            this.button99.Click += new System.EventHandler(this.button_Click);
            // 
            // button98
            // 
            this.button98.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button98.Location = new System.Drawing.Point(402, 390);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(32, 32);
            this.button98.TabIndex = 98;
            this.button98.UseVisualStyleBackColor = true;
            this.button98.Click += new System.EventHandler(this.button_Click);
            // 
            // button97
            // 
            this.button97.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button97.Location = new System.Drawing.Point(364, 390);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(32, 32);
            this.button97.TabIndex = 97;
            this.button97.UseVisualStyleBackColor = true;
            this.button97.Click += new System.EventHandler(this.button_Click);
            // 
            // button96
            // 
            this.button96.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button96.Location = new System.Drawing.Point(326, 390);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(32, 32);
            this.button96.TabIndex = 96;
            this.button96.UseVisualStyleBackColor = true;
            this.button96.Click += new System.EventHandler(this.button_Click);
            // 
            // button95
            // 
            this.button95.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button95.Location = new System.Drawing.Point(288, 390);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(32, 32);
            this.button95.TabIndex = 95;
            this.button95.UseVisualStyleBackColor = true;
            this.button95.Click += new System.EventHandler(this.button_Click);
            // 
            // button94
            // 
            this.button94.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button94.Location = new System.Drawing.Point(250, 390);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(32, 32);
            this.button94.TabIndex = 94;
            this.button94.UseVisualStyleBackColor = true;
            this.button94.Click += new System.EventHandler(this.button_Click);
            // 
            // button93
            // 
            this.button93.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button93.Location = new System.Drawing.Point(212, 390);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(32, 32);
            this.button93.TabIndex = 93;
            this.button93.UseVisualStyleBackColor = true;
            this.button93.Click += new System.EventHandler(this.button_Click);
            // 
            // button92
            // 
            this.button92.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button92.Location = new System.Drawing.Point(174, 390);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(32, 32);
            this.button92.TabIndex = 92;
            this.button92.UseVisualStyleBackColor = true;
            this.button92.Click += new System.EventHandler(this.button_Click);
            // 
            // button91
            // 
            this.button91.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button91.Location = new System.Drawing.Point(136, 390);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(32, 32);
            this.button91.TabIndex = 91;
            this.button91.UseVisualStyleBackColor = true;
            this.button91.Click += new System.EventHandler(this.button_Click);
            // 
            // button90
            // 
            this.button90.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button90.Location = new System.Drawing.Point(98, 390);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(32, 32);
            this.button90.TabIndex = 90;
            this.button90.UseVisualStyleBackColor = true;
            this.button90.Click += new System.EventHandler(this.button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(60, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 31);
            this.label2.TabIndex = 101;
            this.label2.Text = "Α";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(58, 391);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 31);
            this.label12.TabIndex = 111;
            this.label12.Text = "Κ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(60, 353);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 31);
            this.label13.TabIndex = 112;
            this.label13.Text = "Ι";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(58, 315);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 31);
            this.label14.TabIndex = 113;
            this.label14.Text = "Θ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(58, 277);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 31);
            this.label15.TabIndex = 114;
            this.label15.Text = "Η";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(60, 239);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(31, 31);
            this.label16.TabIndex = 115;
            this.label16.Text = "Ζ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(60, 201);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 31);
            this.label17.TabIndex = 116;
            this.label17.Text = "Ε";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(60, 163);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 31);
            this.label18.TabIndex = 117;
            this.label18.Text = "Δ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(60, 125);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 31);
            this.label19.TabIndex = 118;
            this.label19.Text = "Γ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(60, 87);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 31);
            this.label20.TabIndex = 119;
            this.label20.Text = "Β";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(101, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 31);
            this.label1.TabIndex = 120;
            this.label1.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(139, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 31);
            this.label3.TabIndex = 121;
            this.label3.Text = "2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(177, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 31);
            this.label4.TabIndex = 122;
            this.label4.Text = "3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(215, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 31);
            this.label5.TabIndex = 123;
            this.label5.Text = "4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(253, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 31);
            this.label6.TabIndex = 124;
            this.label6.Text = "5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(291, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 31);
            this.label7.TabIndex = 125;
            this.label7.Text = "6";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(329, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 31);
            this.label8.TabIndex = 126;
            this.label8.Text = "7";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(367, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 31);
            this.label9.TabIndex = 127;
            this.label9.Text = "8";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(405, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 31);
            this.label10.TabIndex = 128;
            this.label10.Text = "9";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(434, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 31);
            this.label11.TabIndex = 129;
            this.label11.Text = "10";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.richTextBox1);
            this.panel1.Controls.Add(this.button04);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.button00);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.button01);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.button02);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.button03);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.button05);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button06);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.button07);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button08);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button09);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.button16);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.button17);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.button19);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button20);
            this.panel1.Controls.Add(this.button99);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.button98);
            this.panel1.Controls.Add(this.button22);
            this.panel1.Controls.Add(this.button97);
            this.panel1.Controls.Add(this.button23);
            this.panel1.Controls.Add(this.button96);
            this.panel1.Controls.Add(this.button24);
            this.panel1.Controls.Add(this.button95);
            this.panel1.Controls.Add(this.button25);
            this.panel1.Controls.Add(this.button94);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.button93);
            this.panel1.Controls.Add(this.button27);
            this.panel1.Controls.Add(this.button92);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button91);
            this.panel1.Controls.Add(this.button29);
            this.panel1.Controls.Add(this.button90);
            this.panel1.Controls.Add(this.button30);
            this.panel1.Controls.Add(this.button89);
            this.panel1.Controls.Add(this.button31);
            this.panel1.Controls.Add(this.button88);
            this.panel1.Controls.Add(this.button32);
            this.panel1.Controls.Add(this.button87);
            this.panel1.Controls.Add(this.button33);
            this.panel1.Controls.Add(this.button86);
            this.panel1.Controls.Add(this.button34);
            this.panel1.Controls.Add(this.button85);
            this.panel1.Controls.Add(this.button35);
            this.panel1.Controls.Add(this.button84);
            this.panel1.Controls.Add(this.button36);
            this.panel1.Controls.Add(this.button83);
            this.panel1.Controls.Add(this.button37);
            this.panel1.Controls.Add(this.button82);
            this.panel1.Controls.Add(this.button38);
            this.panel1.Controls.Add(this.button81);
            this.panel1.Controls.Add(this.button39);
            this.panel1.Controls.Add(this.button80);
            this.panel1.Controls.Add(this.button40);
            this.panel1.Controls.Add(this.button79);
            this.panel1.Controls.Add(this.button41);
            this.panel1.Controls.Add(this.button78);
            this.panel1.Controls.Add(this.button42);
            this.panel1.Controls.Add(this.button77);
            this.panel1.Controls.Add(this.button43);
            this.panel1.Controls.Add(this.button76);
            this.panel1.Controls.Add(this.button44);
            this.panel1.Controls.Add(this.button75);
            this.panel1.Controls.Add(this.button45);
            this.panel1.Controls.Add(this.button74);
            this.panel1.Controls.Add(this.button46);
            this.panel1.Controls.Add(this.button73);
            this.panel1.Controls.Add(this.button47);
            this.panel1.Controls.Add(this.button72);
            this.panel1.Controls.Add(this.button48);
            this.panel1.Controls.Add(this.button71);
            this.panel1.Controls.Add(this.button49);
            this.panel1.Controls.Add(this.button70);
            this.panel1.Controls.Add(this.button50);
            this.panel1.Controls.Add(this.button69);
            this.panel1.Controls.Add(this.button51);
            this.panel1.Controls.Add(this.button68);
            this.panel1.Controls.Add(this.button52);
            this.panel1.Controls.Add(this.button67);
            this.panel1.Controls.Add(this.button53);
            this.panel1.Controls.Add(this.button66);
            this.panel1.Controls.Add(this.button54);
            this.panel1.Controls.Add(this.button65);
            this.panel1.Controls.Add(this.button55);
            this.panel1.Controls.Add(this.button64);
            this.panel1.Controls.Add(this.button56);
            this.panel1.Controls.Add(this.button63);
            this.panel1.Controls.Add(this.button57);
            this.panel1.Controls.Add(this.button62);
            this.panel1.Controls.Add(this.button58);
            this.panel1.Controls.Add(this.button61);
            this.panel1.Controls.Add(this.button59);
            this.panel1.Controls.Add(this.button60);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 586);
            this.panel1.TabIndex = 130;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(98, 452);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(374, 69);
            this.richTextBox1.TabIndex = 130;
            this.richTextBox1.Text = "";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.richTextBox2);
            this.panel2.Controls.Add(this.button04E);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.button00E);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.button01E);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.button02E);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.button03E);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.button05E);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.button06E);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.button07E);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.button08E);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.button09E);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.button10E);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.button11E);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.button12E);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.button13E);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.button14E);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Controls.Add(this.button15E);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.button16E);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.button17E);
            this.panel2.Controls.Add(this.label38);
            this.panel2.Controls.Add(this.button18E);
            this.panel2.Controls.Add(this.label39);
            this.panel2.Controls.Add(this.button19E);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.button20E);
            this.panel2.Controls.Add(this.button99E);
            this.panel2.Controls.Add(this.button21E);
            this.panel2.Controls.Add(this.button98E);
            this.panel2.Controls.Add(this.button22E);
            this.panel2.Controls.Add(this.button97E);
            this.panel2.Controls.Add(this.button23E);
            this.panel2.Controls.Add(this.button96E);
            this.panel2.Controls.Add(this.button24E);
            this.panel2.Controls.Add(this.button95E);
            this.panel2.Controls.Add(this.button25E);
            this.panel2.Controls.Add(this.button94E);
            this.panel2.Controls.Add(this.button26E);
            this.panel2.Controls.Add(this.button93E);
            this.panel2.Controls.Add(this.button27E);
            this.panel2.Controls.Add(this.button92E);
            this.panel2.Controls.Add(this.button28E);
            this.panel2.Controls.Add(this.button91E);
            this.panel2.Controls.Add(this.button29E);
            this.panel2.Controls.Add(this.button90E);
            this.panel2.Controls.Add(this.button30E);
            this.panel2.Controls.Add(this.button89E);
            this.panel2.Controls.Add(this.button31E);
            this.panel2.Controls.Add(this.button88E);
            this.panel2.Controls.Add(this.button32E);
            this.panel2.Controls.Add(this.button87E);
            this.panel2.Controls.Add(this.button33E);
            this.panel2.Controls.Add(this.button86E);
            this.panel2.Controls.Add(this.button34E);
            this.panel2.Controls.Add(this.button85E);
            this.panel2.Controls.Add(this.button35E);
            this.panel2.Controls.Add(this.button84E);
            this.panel2.Controls.Add(this.button36E);
            this.panel2.Controls.Add(this.button83E);
            this.panel2.Controls.Add(this.button37E);
            this.panel2.Controls.Add(this.button82E);
            this.panel2.Controls.Add(this.button38E);
            this.panel2.Controls.Add(this.button81E);
            this.panel2.Controls.Add(this.button39E);
            this.panel2.Controls.Add(this.button80E);
            this.panel2.Controls.Add(this.button40E);
            this.panel2.Controls.Add(this.button79E);
            this.panel2.Controls.Add(this.button41E);
            this.panel2.Controls.Add(this.button78E);
            this.panel2.Controls.Add(this.button42E);
            this.panel2.Controls.Add(this.button77E);
            this.panel2.Controls.Add(this.button43E);
            this.panel2.Controls.Add(this.button76E);
            this.panel2.Controls.Add(this.button44E);
            this.panel2.Controls.Add(this.button75E);
            this.panel2.Controls.Add(this.button45E);
            this.panel2.Controls.Add(this.button74E);
            this.panel2.Controls.Add(this.button46E);
            this.panel2.Controls.Add(this.button73E);
            this.panel2.Controls.Add(this.button47E);
            this.panel2.Controls.Add(this.button72E);
            this.panel2.Controls.Add(this.button48E);
            this.panel2.Controls.Add(this.button71E);
            this.panel2.Controls.Add(this.button49E);
            this.panel2.Controls.Add(this.button70E);
            this.panel2.Controls.Add(this.button50E);
            this.panel2.Controls.Add(this.button69E);
            this.panel2.Controls.Add(this.button51E);
            this.panel2.Controls.Add(this.button68E);
            this.panel2.Controls.Add(this.button52E);
            this.panel2.Controls.Add(this.button67E);
            this.panel2.Controls.Add(this.button53E);
            this.panel2.Controls.Add(this.button66E);
            this.panel2.Controls.Add(this.button54E);
            this.panel2.Controls.Add(this.button65E);
            this.panel2.Controls.Add(this.button55E);
            this.panel2.Controls.Add(this.button64E);
            this.panel2.Controls.Add(this.button56E);
            this.panel2.Controls.Add(this.button63E);
            this.panel2.Controls.Add(this.button57E);
            this.panel2.Controls.Add(this.button62E);
            this.panel2.Controls.Add(this.button58E);
            this.panel2.Controls.Add(this.button61E);
            this.panel2.Controls.Add(this.button59E);
            this.panel2.Controls.Add(this.button60E);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(708, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(532, 586);
            this.panel2.TabIndex = 131;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(93, 452);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(374, 69);
            this.richTextBox2.TabIndex = 131;
            this.richTextBox2.Text = "";
            // 
            // button04E
            // 
            this.button04E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button04E.Location = new System.Drawing.Point(245, 48);
            this.button04E.Name = "button04E";
            this.button04E.Size = new System.Drawing.Size(32, 32);
            this.button04E.TabIndex = 4;
            this.button04E.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(429, 14);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 31);
            this.label21.TabIndex = 129;
            this.label21.Text = "10";
            // 
            // button00E
            // 
            this.button00E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button00E.Location = new System.Drawing.Point(93, 48);
            this.button00E.Name = "button00E";
            this.button00E.Size = new System.Drawing.Size(32, 32);
            this.button00E.TabIndex = 0;
            this.button00E.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(400, 14);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 31);
            this.label22.TabIndex = 128;
            this.label22.Text = "9";
            // 
            // button01E
            // 
            this.button01E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button01E.Location = new System.Drawing.Point(131, 48);
            this.button01E.Name = "button01E";
            this.button01E.Size = new System.Drawing.Size(32, 32);
            this.button01E.TabIndex = 1;
            this.button01E.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(362, 14);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 31);
            this.label23.TabIndex = 127;
            this.label23.Text = "8";
            // 
            // button02E
            // 
            this.button02E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button02E.Location = new System.Drawing.Point(169, 48);
            this.button02E.Name = "button02E";
            this.button02E.Size = new System.Drawing.Size(32, 32);
            this.button02E.TabIndex = 2;
            this.button02E.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(324, 14);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 31);
            this.label24.TabIndex = 126;
            this.label24.Text = "7";
            // 
            // button03E
            // 
            this.button03E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button03E.Location = new System.Drawing.Point(207, 48);
            this.button03E.Name = "button03E";
            this.button03E.Size = new System.Drawing.Size(32, 32);
            this.button03E.TabIndex = 3;
            this.button03E.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(286, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 31);
            this.label25.TabIndex = 125;
            this.label25.Text = "6";
            // 
            // button05E
            // 
            this.button05E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button05E.Location = new System.Drawing.Point(283, 48);
            this.button05E.Name = "button05E";
            this.button05E.Size = new System.Drawing.Size(32, 32);
            this.button05E.TabIndex = 5;
            this.button05E.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(248, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 31);
            this.label26.TabIndex = 124;
            this.label26.Text = "5";
            // 
            // button06E
            // 
            this.button06E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button06E.Location = new System.Drawing.Point(321, 48);
            this.button06E.Name = "button06E";
            this.button06E.Size = new System.Drawing.Size(32, 32);
            this.button06E.TabIndex = 6;
            this.button06E.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(210, 14);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 31);
            this.label27.TabIndex = 123;
            this.label27.Text = "4";
            // 
            // button07E
            // 
            this.button07E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button07E.Location = new System.Drawing.Point(359, 48);
            this.button07E.Name = "button07E";
            this.button07E.Size = new System.Drawing.Size(32, 32);
            this.button07E.TabIndex = 7;
            this.button07E.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(172, 14);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 31);
            this.label28.TabIndex = 122;
            this.label28.Text = "3";
            // 
            // button08E
            // 
            this.button08E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button08E.Location = new System.Drawing.Point(397, 48);
            this.button08E.Name = "button08E";
            this.button08E.Size = new System.Drawing.Size(32, 32);
            this.button08E.TabIndex = 8;
            this.button08E.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(134, 14);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 31);
            this.label29.TabIndex = 121;
            this.label29.Text = "2";
            // 
            // button09E
            // 
            this.button09E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button09E.Location = new System.Drawing.Point(435, 48);
            this.button09E.Name = "button09E";
            this.button09E.Size = new System.Drawing.Size(32, 32);
            this.button09E.TabIndex = 9;
            this.button09E.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(96, 14);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 31);
            this.label30.TabIndex = 120;
            this.label30.Text = "1";
            // 
            // button10E
            // 
            this.button10E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button10E.Location = new System.Drawing.Point(93, 86);
            this.button10E.Name = "button10E";
            this.button10E.Size = new System.Drawing.Size(32, 32);
            this.button10E.TabIndex = 10;
            this.button10E.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(55, 87);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(32, 31);
            this.label31.TabIndex = 119;
            this.label31.Text = "Β";
            // 
            // button11E
            // 
            this.button11E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button11E.Location = new System.Drawing.Point(131, 86);
            this.button11E.Name = "button11E";
            this.button11E.Size = new System.Drawing.Size(32, 32);
            this.button11E.TabIndex = 11;
            this.button11E.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(55, 125);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(30, 31);
            this.label32.TabIndex = 118;
            this.label32.Text = "Γ";
            // 
            // button12E
            // 
            this.button12E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button12E.Location = new System.Drawing.Point(169, 86);
            this.button12E.Name = "button12E";
            this.button12E.Size = new System.Drawing.Size(32, 32);
            this.button12E.TabIndex = 12;
            this.button12E.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(55, 163);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(32, 31);
            this.label33.TabIndex = 117;
            this.label33.Text = "Δ";
            // 
            // button13E
            // 
            this.button13E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button13E.Location = new System.Drawing.Point(207, 86);
            this.button13E.Name = "button13E";
            this.button13E.Size = new System.Drawing.Size(32, 32);
            this.button13E.TabIndex = 13;
            this.button13E.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(55, 201);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 31);
            this.label34.TabIndex = 116;
            this.label34.Text = "Ε";
            // 
            // button14E
            // 
            this.button14E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button14E.Location = new System.Drawing.Point(245, 86);
            this.button14E.Name = "button14E";
            this.button14E.Size = new System.Drawing.Size(32, 32);
            this.button14E.TabIndex = 14;
            this.button14E.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(55, 239);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(31, 31);
            this.label35.TabIndex = 115;
            this.label35.Text = "Ζ";
            // 
            // button15E
            // 
            this.button15E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button15E.Location = new System.Drawing.Point(283, 86);
            this.button15E.Name = "button15E";
            this.button15E.Size = new System.Drawing.Size(32, 32);
            this.button15E.TabIndex = 15;
            this.button15E.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(53, 277);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(34, 31);
            this.label36.TabIndex = 114;
            this.label36.Text = "Η";
            // 
            // button16E
            // 
            this.button16E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button16E.Location = new System.Drawing.Point(321, 86);
            this.button16E.Name = "button16E";
            this.button16E.Size = new System.Drawing.Size(32, 32);
            this.button16E.TabIndex = 16;
            this.button16E.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(53, 315);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 31);
            this.label37.TabIndex = 113;
            this.label37.Text = "Θ";
            // 
            // button17E
            // 
            this.button17E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button17E.Location = new System.Drawing.Point(359, 86);
            this.button17E.Name = "button17E";
            this.button17E.Size = new System.Drawing.Size(32, 32);
            this.button17E.TabIndex = 17;
            this.button17E.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(55, 353);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(22, 31);
            this.label38.TabIndex = 112;
            this.label38.Text = "Ι";
            // 
            // button18E
            // 
            this.button18E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button18E.Location = new System.Drawing.Point(397, 86);
            this.button18E.Name = "button18E";
            this.button18E.Size = new System.Drawing.Size(32, 32);
            this.button18E.TabIndex = 18;
            this.button18E.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(53, 391);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(32, 31);
            this.label39.TabIndex = 111;
            this.label39.Text = "Κ";
            // 
            // button19E
            // 
            this.button19E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button19E.Location = new System.Drawing.Point(435, 86);
            this.button19E.Name = "button19E";
            this.button19E.Size = new System.Drawing.Size(32, 32);
            this.button19E.TabIndex = 19;
            this.button19E.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(55, 49);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(32, 31);
            this.label40.TabIndex = 101;
            this.label40.Text = "Α";
            // 
            // button20E
            // 
            this.button20E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button20E.Location = new System.Drawing.Point(93, 124);
            this.button20E.Name = "button20E";
            this.button20E.Size = new System.Drawing.Size(32, 32);
            this.button20E.TabIndex = 20;
            this.button20E.UseVisualStyleBackColor = true;
            // 
            // button99E
            // 
            this.button99E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button99E.Location = new System.Drawing.Point(435, 390);
            this.button99E.Name = "button99E";
            this.button99E.Size = new System.Drawing.Size(32, 32);
            this.button99E.TabIndex = 99;
            this.button99E.UseVisualStyleBackColor = true;
            // 
            // button21E
            // 
            this.button21E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button21E.Location = new System.Drawing.Point(131, 124);
            this.button21E.Name = "button21E";
            this.button21E.Size = new System.Drawing.Size(32, 32);
            this.button21E.TabIndex = 21;
            this.button21E.UseVisualStyleBackColor = true;
            // 
            // button98E
            // 
            this.button98E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button98E.Location = new System.Drawing.Point(397, 390);
            this.button98E.Name = "button98E";
            this.button98E.Size = new System.Drawing.Size(32, 32);
            this.button98E.TabIndex = 98;
            this.button98E.UseVisualStyleBackColor = true;
            // 
            // button22E
            // 
            this.button22E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button22E.Location = new System.Drawing.Point(169, 124);
            this.button22E.Name = "button22E";
            this.button22E.Size = new System.Drawing.Size(32, 32);
            this.button22E.TabIndex = 22;
            this.button22E.UseVisualStyleBackColor = true;
            // 
            // button97E
            // 
            this.button97E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button97E.Location = new System.Drawing.Point(359, 390);
            this.button97E.Name = "button97E";
            this.button97E.Size = new System.Drawing.Size(32, 32);
            this.button97E.TabIndex = 97;
            this.button97E.UseVisualStyleBackColor = true;
            // 
            // button23E
            // 
            this.button23E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button23E.Location = new System.Drawing.Point(207, 124);
            this.button23E.Name = "button23E";
            this.button23E.Size = new System.Drawing.Size(32, 32);
            this.button23E.TabIndex = 23;
            this.button23E.UseVisualStyleBackColor = true;
            // 
            // button96E
            // 
            this.button96E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button96E.Location = new System.Drawing.Point(321, 390);
            this.button96E.Name = "button96E";
            this.button96E.Size = new System.Drawing.Size(32, 32);
            this.button96E.TabIndex = 96;
            this.button96E.UseVisualStyleBackColor = true;
            // 
            // button24E
            // 
            this.button24E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button24E.Location = new System.Drawing.Point(245, 124);
            this.button24E.Name = "button24E";
            this.button24E.Size = new System.Drawing.Size(32, 32);
            this.button24E.TabIndex = 24;
            this.button24E.UseVisualStyleBackColor = true;
            // 
            // button95E
            // 
            this.button95E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button95E.Location = new System.Drawing.Point(283, 390);
            this.button95E.Name = "button95E";
            this.button95E.Size = new System.Drawing.Size(32, 32);
            this.button95E.TabIndex = 95;
            this.button95E.UseVisualStyleBackColor = true;
            // 
            // button25E
            // 
            this.button25E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button25E.Location = new System.Drawing.Point(283, 124);
            this.button25E.Name = "button25E";
            this.button25E.Size = new System.Drawing.Size(32, 32);
            this.button25E.TabIndex = 25;
            this.button25E.UseVisualStyleBackColor = true;
            // 
            // button94E
            // 
            this.button94E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button94E.Location = new System.Drawing.Point(245, 390);
            this.button94E.Name = "button94E";
            this.button94E.Size = new System.Drawing.Size(32, 32);
            this.button94E.TabIndex = 94;
            this.button94E.UseVisualStyleBackColor = true;
            // 
            // button26E
            // 
            this.button26E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button26E.Location = new System.Drawing.Point(321, 124);
            this.button26E.Name = "button26E";
            this.button26E.Size = new System.Drawing.Size(32, 32);
            this.button26E.TabIndex = 26;
            this.button26E.UseVisualStyleBackColor = true;
            // 
            // button93E
            // 
            this.button93E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button93E.Location = new System.Drawing.Point(207, 390);
            this.button93E.Name = "button93E";
            this.button93E.Size = new System.Drawing.Size(32, 32);
            this.button93E.TabIndex = 93;
            this.button93E.UseVisualStyleBackColor = true;
            // 
            // button27E
            // 
            this.button27E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button27E.Location = new System.Drawing.Point(359, 124);
            this.button27E.Name = "button27E";
            this.button27E.Size = new System.Drawing.Size(32, 32);
            this.button27E.TabIndex = 27;
            this.button27E.UseVisualStyleBackColor = true;
            // 
            // button92E
            // 
            this.button92E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button92E.Location = new System.Drawing.Point(169, 390);
            this.button92E.Name = "button92E";
            this.button92E.Size = new System.Drawing.Size(32, 32);
            this.button92E.TabIndex = 92;
            this.button92E.UseVisualStyleBackColor = true;
            // 
            // button28E
            // 
            this.button28E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button28E.Location = new System.Drawing.Point(397, 124);
            this.button28E.Name = "button28E";
            this.button28E.Size = new System.Drawing.Size(32, 32);
            this.button28E.TabIndex = 28;
            this.button28E.UseVisualStyleBackColor = true;
            // 
            // button91E
            // 
            this.button91E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button91E.Location = new System.Drawing.Point(131, 390);
            this.button91E.Name = "button91E";
            this.button91E.Size = new System.Drawing.Size(32, 32);
            this.button91E.TabIndex = 91;
            this.button91E.UseVisualStyleBackColor = true;
            // 
            // button29E
            // 
            this.button29E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button29E.Location = new System.Drawing.Point(435, 124);
            this.button29E.Name = "button29E";
            this.button29E.Size = new System.Drawing.Size(32, 32);
            this.button29E.TabIndex = 29;
            this.button29E.UseVisualStyleBackColor = true;
            // 
            // button90E
            // 
            this.button90E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button90E.Location = new System.Drawing.Point(93, 390);
            this.button90E.Name = "button90E";
            this.button90E.Size = new System.Drawing.Size(32, 32);
            this.button90E.TabIndex = 90;
            this.button90E.UseVisualStyleBackColor = true;
            // 
            // button30E
            // 
            this.button30E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button30E.Location = new System.Drawing.Point(93, 162);
            this.button30E.Name = "button30E";
            this.button30E.Size = new System.Drawing.Size(32, 32);
            this.button30E.TabIndex = 30;
            this.button30E.UseVisualStyleBackColor = true;
            // 
            // button89E
            // 
            this.button89E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button89E.Location = new System.Drawing.Point(435, 352);
            this.button89E.Name = "button89E";
            this.button89E.Size = new System.Drawing.Size(32, 32);
            this.button89E.TabIndex = 89;
            this.button89E.UseVisualStyleBackColor = true;
            // 
            // button31E
            // 
            this.button31E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button31E.Location = new System.Drawing.Point(131, 162);
            this.button31E.Name = "button31E";
            this.button31E.Size = new System.Drawing.Size(32, 32);
            this.button31E.TabIndex = 31;
            this.button31E.UseVisualStyleBackColor = true;
            // 
            // button88E
            // 
            this.button88E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button88E.Location = new System.Drawing.Point(397, 352);
            this.button88E.Name = "button88E";
            this.button88E.Size = new System.Drawing.Size(32, 32);
            this.button88E.TabIndex = 88;
            this.button88E.UseVisualStyleBackColor = true;
            // 
            // button32E
            // 
            this.button32E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button32E.Location = new System.Drawing.Point(169, 162);
            this.button32E.Name = "button32E";
            this.button32E.Size = new System.Drawing.Size(32, 32);
            this.button32E.TabIndex = 32;
            this.button32E.UseVisualStyleBackColor = true;
            // 
            // button87E
            // 
            this.button87E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button87E.Location = new System.Drawing.Point(359, 352);
            this.button87E.Name = "button87E";
            this.button87E.Size = new System.Drawing.Size(32, 32);
            this.button87E.TabIndex = 87;
            this.button87E.UseVisualStyleBackColor = true;
            // 
            // button33E
            // 
            this.button33E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button33E.Location = new System.Drawing.Point(207, 162);
            this.button33E.Name = "button33E";
            this.button33E.Size = new System.Drawing.Size(32, 32);
            this.button33E.TabIndex = 33;
            this.button33E.UseVisualStyleBackColor = true;
            // 
            // button86E
            // 
            this.button86E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button86E.Location = new System.Drawing.Point(321, 352);
            this.button86E.Name = "button86E";
            this.button86E.Size = new System.Drawing.Size(32, 32);
            this.button86E.TabIndex = 86;
            this.button86E.UseVisualStyleBackColor = true;
            // 
            // button34E
            // 
            this.button34E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button34E.Location = new System.Drawing.Point(245, 162);
            this.button34E.Name = "button34E";
            this.button34E.Size = new System.Drawing.Size(32, 32);
            this.button34E.TabIndex = 34;
            this.button34E.UseVisualStyleBackColor = true;
            // 
            // button85E
            // 
            this.button85E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button85E.Location = new System.Drawing.Point(283, 352);
            this.button85E.Name = "button85E";
            this.button85E.Size = new System.Drawing.Size(32, 32);
            this.button85E.TabIndex = 85;
            this.button85E.UseVisualStyleBackColor = true;
            // 
            // button35E
            // 
            this.button35E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button35E.Location = new System.Drawing.Point(283, 162);
            this.button35E.Name = "button35E";
            this.button35E.Size = new System.Drawing.Size(32, 32);
            this.button35E.TabIndex = 35;
            this.button35E.UseVisualStyleBackColor = true;
            // 
            // button84E
            // 
            this.button84E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button84E.Location = new System.Drawing.Point(245, 352);
            this.button84E.Name = "button84E";
            this.button84E.Size = new System.Drawing.Size(32, 32);
            this.button84E.TabIndex = 84;
            this.button84E.UseVisualStyleBackColor = true;
            // 
            // button36E
            // 
            this.button36E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button36E.Location = new System.Drawing.Point(321, 162);
            this.button36E.Name = "button36E";
            this.button36E.Size = new System.Drawing.Size(32, 32);
            this.button36E.TabIndex = 36;
            this.button36E.UseVisualStyleBackColor = true;
            // 
            // button83E
            // 
            this.button83E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button83E.Location = new System.Drawing.Point(207, 352);
            this.button83E.Name = "button83E";
            this.button83E.Size = new System.Drawing.Size(32, 32);
            this.button83E.TabIndex = 83;
            this.button83E.UseVisualStyleBackColor = true;
            // 
            // button37E
            // 
            this.button37E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button37E.Location = new System.Drawing.Point(359, 162);
            this.button37E.Name = "button37E";
            this.button37E.Size = new System.Drawing.Size(32, 32);
            this.button37E.TabIndex = 37;
            this.button37E.UseVisualStyleBackColor = true;
            // 
            // button82E
            // 
            this.button82E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button82E.Location = new System.Drawing.Point(169, 352);
            this.button82E.Name = "button82E";
            this.button82E.Size = new System.Drawing.Size(32, 32);
            this.button82E.TabIndex = 82;
            this.button82E.UseVisualStyleBackColor = true;
            // 
            // button38E
            // 
            this.button38E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button38E.Location = new System.Drawing.Point(397, 162);
            this.button38E.Name = "button38E";
            this.button38E.Size = new System.Drawing.Size(32, 32);
            this.button38E.TabIndex = 38;
            this.button38E.UseVisualStyleBackColor = true;
            // 
            // button81E
            // 
            this.button81E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button81E.Location = new System.Drawing.Point(131, 352);
            this.button81E.Name = "button81E";
            this.button81E.Size = new System.Drawing.Size(32, 32);
            this.button81E.TabIndex = 81;
            this.button81E.UseVisualStyleBackColor = true;
            // 
            // button39E
            // 
            this.button39E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button39E.Location = new System.Drawing.Point(435, 162);
            this.button39E.Name = "button39E";
            this.button39E.Size = new System.Drawing.Size(32, 32);
            this.button39E.TabIndex = 39;
            this.button39E.UseVisualStyleBackColor = true;
            // 
            // button80E
            // 
            this.button80E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button80E.Location = new System.Drawing.Point(93, 352);
            this.button80E.Name = "button80E";
            this.button80E.Size = new System.Drawing.Size(32, 32);
            this.button80E.TabIndex = 80;
            this.button80E.UseVisualStyleBackColor = true;
            // 
            // button40E
            // 
            this.button40E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button40E.Location = new System.Drawing.Point(93, 200);
            this.button40E.Name = "button40E";
            this.button40E.Size = new System.Drawing.Size(32, 32);
            this.button40E.TabIndex = 40;
            this.button40E.UseVisualStyleBackColor = true;
            // 
            // button79E
            // 
            this.button79E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button79E.Location = new System.Drawing.Point(435, 314);
            this.button79E.Name = "button79E";
            this.button79E.Size = new System.Drawing.Size(32, 32);
            this.button79E.TabIndex = 79;
            this.button79E.UseVisualStyleBackColor = true;
            // 
            // button41E
            // 
            this.button41E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button41E.Location = new System.Drawing.Point(131, 200);
            this.button41E.Name = "button41E";
            this.button41E.Size = new System.Drawing.Size(32, 32);
            this.button41E.TabIndex = 41;
            this.button41E.UseVisualStyleBackColor = true;
            // 
            // button78E
            // 
            this.button78E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button78E.Location = new System.Drawing.Point(397, 314);
            this.button78E.Name = "button78E";
            this.button78E.Size = new System.Drawing.Size(32, 32);
            this.button78E.TabIndex = 78;
            this.button78E.UseVisualStyleBackColor = true;
            // 
            // button42E
            // 
            this.button42E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button42E.Location = new System.Drawing.Point(169, 200);
            this.button42E.Name = "button42E";
            this.button42E.Size = new System.Drawing.Size(32, 32);
            this.button42E.TabIndex = 42;
            this.button42E.UseVisualStyleBackColor = true;
            // 
            // button77E
            // 
            this.button77E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button77E.Location = new System.Drawing.Point(359, 314);
            this.button77E.Name = "button77E";
            this.button77E.Size = new System.Drawing.Size(32, 32);
            this.button77E.TabIndex = 77;
            this.button77E.UseVisualStyleBackColor = true;
            // 
            // button43E
            // 
            this.button43E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button43E.Location = new System.Drawing.Point(207, 200);
            this.button43E.Name = "button43E";
            this.button43E.Size = new System.Drawing.Size(32, 32);
            this.button43E.TabIndex = 43;
            this.button43E.UseVisualStyleBackColor = true;
            // 
            // button76E
            // 
            this.button76E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button76E.Location = new System.Drawing.Point(321, 314);
            this.button76E.Name = "button76E";
            this.button76E.Size = new System.Drawing.Size(32, 32);
            this.button76E.TabIndex = 76;
            this.button76E.UseVisualStyleBackColor = true;
            // 
            // button44E
            // 
            this.button44E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button44E.Location = new System.Drawing.Point(245, 200);
            this.button44E.Name = "button44E";
            this.button44E.Size = new System.Drawing.Size(32, 32);
            this.button44E.TabIndex = 44;
            this.button44E.UseVisualStyleBackColor = true;
            // 
            // button75E
            // 
            this.button75E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button75E.Location = new System.Drawing.Point(283, 314);
            this.button75E.Name = "button75E";
            this.button75E.Size = new System.Drawing.Size(32, 32);
            this.button75E.TabIndex = 75;
            this.button75E.UseVisualStyleBackColor = true;
            // 
            // button45E
            // 
            this.button45E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button45E.Location = new System.Drawing.Point(283, 200);
            this.button45E.Name = "button45E";
            this.button45E.Size = new System.Drawing.Size(32, 32);
            this.button45E.TabIndex = 45;
            this.button45E.UseVisualStyleBackColor = true;
            // 
            // button74E
            // 
            this.button74E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button74E.Location = new System.Drawing.Point(245, 314);
            this.button74E.Name = "button74E";
            this.button74E.Size = new System.Drawing.Size(32, 32);
            this.button74E.TabIndex = 74;
            this.button74E.UseVisualStyleBackColor = true;
            // 
            // button46E
            // 
            this.button46E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button46E.Location = new System.Drawing.Point(321, 200);
            this.button46E.Name = "button46E";
            this.button46E.Size = new System.Drawing.Size(32, 32);
            this.button46E.TabIndex = 46;
            this.button46E.UseVisualStyleBackColor = true;
            // 
            // button73E
            // 
            this.button73E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button73E.Location = new System.Drawing.Point(207, 314);
            this.button73E.Name = "button73E";
            this.button73E.Size = new System.Drawing.Size(32, 32);
            this.button73E.TabIndex = 73;
            this.button73E.UseVisualStyleBackColor = true;
            // 
            // button47E
            // 
            this.button47E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button47E.Location = new System.Drawing.Point(359, 200);
            this.button47E.Name = "button47E";
            this.button47E.Size = new System.Drawing.Size(32, 32);
            this.button47E.TabIndex = 47;
            this.button47E.UseVisualStyleBackColor = true;
            // 
            // button72E
            // 
            this.button72E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button72E.Location = new System.Drawing.Point(169, 314);
            this.button72E.Name = "button72E";
            this.button72E.Size = new System.Drawing.Size(32, 32);
            this.button72E.TabIndex = 72;
            this.button72E.UseVisualStyleBackColor = true;
            // 
            // button48E
            // 
            this.button48E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button48E.Location = new System.Drawing.Point(397, 200);
            this.button48E.Name = "button48E";
            this.button48E.Size = new System.Drawing.Size(32, 32);
            this.button48E.TabIndex = 48;
            this.button48E.UseVisualStyleBackColor = true;
            // 
            // button71E
            // 
            this.button71E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button71E.Location = new System.Drawing.Point(131, 314);
            this.button71E.Name = "button71E";
            this.button71E.Size = new System.Drawing.Size(32, 32);
            this.button71E.TabIndex = 71;
            this.button71E.UseVisualStyleBackColor = true;
            // 
            // button49E
            // 
            this.button49E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button49E.Location = new System.Drawing.Point(435, 200);
            this.button49E.Name = "button49E";
            this.button49E.Size = new System.Drawing.Size(32, 32);
            this.button49E.TabIndex = 49;
            this.button49E.UseVisualStyleBackColor = true;
            // 
            // button70E
            // 
            this.button70E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button70E.Location = new System.Drawing.Point(93, 314);
            this.button70E.Name = "button70E";
            this.button70E.Size = new System.Drawing.Size(32, 32);
            this.button70E.TabIndex = 70;
            this.button70E.UseVisualStyleBackColor = true;
            // 
            // button50E
            // 
            this.button50E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button50E.Location = new System.Drawing.Point(93, 238);
            this.button50E.Name = "button50E";
            this.button50E.Size = new System.Drawing.Size(32, 32);
            this.button50E.TabIndex = 50;
            this.button50E.UseVisualStyleBackColor = true;
            // 
            // button69E
            // 
            this.button69E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button69E.Location = new System.Drawing.Point(435, 276);
            this.button69E.Name = "button69E";
            this.button69E.Size = new System.Drawing.Size(32, 32);
            this.button69E.TabIndex = 69;
            this.button69E.UseVisualStyleBackColor = true;
            // 
            // button51E
            // 
            this.button51E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button51E.Location = new System.Drawing.Point(131, 238);
            this.button51E.Name = "button51E";
            this.button51E.Size = new System.Drawing.Size(32, 32);
            this.button51E.TabIndex = 51;
            this.button51E.UseVisualStyleBackColor = true;
            // 
            // button68E
            // 
            this.button68E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button68E.Location = new System.Drawing.Point(397, 276);
            this.button68E.Name = "button68E";
            this.button68E.Size = new System.Drawing.Size(32, 32);
            this.button68E.TabIndex = 68;
            this.button68E.UseVisualStyleBackColor = true;
            // 
            // button52E
            // 
            this.button52E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button52E.Location = new System.Drawing.Point(169, 238);
            this.button52E.Name = "button52E";
            this.button52E.Size = new System.Drawing.Size(32, 32);
            this.button52E.TabIndex = 52;
            this.button52E.UseVisualStyleBackColor = true;
            // 
            // button67E
            // 
            this.button67E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button67E.Location = new System.Drawing.Point(359, 276);
            this.button67E.Name = "button67E";
            this.button67E.Size = new System.Drawing.Size(32, 32);
            this.button67E.TabIndex = 67;
            this.button67E.UseVisualStyleBackColor = true;
            // 
            // button53E
            // 
            this.button53E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button53E.Location = new System.Drawing.Point(207, 238);
            this.button53E.Name = "button53E";
            this.button53E.Size = new System.Drawing.Size(32, 32);
            this.button53E.TabIndex = 53;
            this.button53E.UseVisualStyleBackColor = true;
            // 
            // button66E
            // 
            this.button66E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button66E.Location = new System.Drawing.Point(321, 276);
            this.button66E.Name = "button66E";
            this.button66E.Size = new System.Drawing.Size(32, 32);
            this.button66E.TabIndex = 66;
            this.button66E.UseVisualStyleBackColor = true;
            // 
            // button54E
            // 
            this.button54E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button54E.Location = new System.Drawing.Point(245, 238);
            this.button54E.Name = "button54E";
            this.button54E.Size = new System.Drawing.Size(32, 32);
            this.button54E.TabIndex = 54;
            this.button54E.UseVisualStyleBackColor = true;
            // 
            // button65E
            // 
            this.button65E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button65E.Location = new System.Drawing.Point(283, 276);
            this.button65E.Name = "button65E";
            this.button65E.Size = new System.Drawing.Size(32, 32);
            this.button65E.TabIndex = 65;
            this.button65E.UseVisualStyleBackColor = true;
            // 
            // button55E
            // 
            this.button55E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button55E.Location = new System.Drawing.Point(283, 238);
            this.button55E.Name = "button55E";
            this.button55E.Size = new System.Drawing.Size(32, 32);
            this.button55E.TabIndex = 55;
            this.button55E.UseVisualStyleBackColor = true;
            // 
            // button64E
            // 
            this.button64E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button64E.Location = new System.Drawing.Point(245, 276);
            this.button64E.Name = "button64E";
            this.button64E.Size = new System.Drawing.Size(32, 32);
            this.button64E.TabIndex = 64;
            this.button64E.UseVisualStyleBackColor = true;
            // 
            // button56E
            // 
            this.button56E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button56E.Location = new System.Drawing.Point(321, 238);
            this.button56E.Name = "button56E";
            this.button56E.Size = new System.Drawing.Size(32, 32);
            this.button56E.TabIndex = 56;
            this.button56E.UseVisualStyleBackColor = true;
            // 
            // button63E
            // 
            this.button63E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button63E.Location = new System.Drawing.Point(207, 276);
            this.button63E.Name = "button63E";
            this.button63E.Size = new System.Drawing.Size(32, 32);
            this.button63E.TabIndex = 63;
            this.button63E.UseVisualStyleBackColor = true;
            // 
            // button57E
            // 
            this.button57E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button57E.Location = new System.Drawing.Point(359, 238);
            this.button57E.Name = "button57E";
            this.button57E.Size = new System.Drawing.Size(32, 32);
            this.button57E.TabIndex = 57;
            this.button57E.UseVisualStyleBackColor = true;
            // 
            // button62E
            // 
            this.button62E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button62E.Location = new System.Drawing.Point(169, 276);
            this.button62E.Name = "button62E";
            this.button62E.Size = new System.Drawing.Size(32, 32);
            this.button62E.TabIndex = 62;
            this.button62E.UseVisualStyleBackColor = true;
            // 
            // button58E
            // 
            this.button58E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button58E.Location = new System.Drawing.Point(397, 238);
            this.button58E.Name = "button58E";
            this.button58E.Size = new System.Drawing.Size(32, 32);
            this.button58E.TabIndex = 58;
            this.button58E.UseVisualStyleBackColor = true;
            // 
            // button61E
            // 
            this.button61E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button61E.Location = new System.Drawing.Point(131, 276);
            this.button61E.Name = "button61E";
            this.button61E.Size = new System.Drawing.Size(32, 32);
            this.button61E.TabIndex = 61;
            this.button61E.UseVisualStyleBackColor = true;
            // 
            // button59E
            // 
            this.button59E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button59E.Location = new System.Drawing.Point(435, 238);
            this.button59E.Name = "button59E";
            this.button59E.Size = new System.Drawing.Size(32, 32);
            this.button59E.TabIndex = 59;
            this.button59E.UseVisualStyleBackColor = true;
            // 
            // button60E
            // 
            this.button60E.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button60E.Location = new System.Drawing.Point(93, 276);
            this.button60E.Name = "button60E";
            this.button60E.Size = new System.Drawing.Size(32, 32);
            this.button60E.TabIndex = 60;
            this.button60E.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(609, 112);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(27, 30);
            this.label41.TabIndex = 133;
            this.label41.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(609, 216);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(27, 30);
            this.label42.TabIndex = 134;
            this.label42.Text = "0";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(586, 82);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(86, 30);
            this.label43.TabIndex = 135;
            this.label43.Text = "TRIES:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(586, 186);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(79, 30);
            this.label44.TabIndex = 136;
            this.label44.Text = "TIME:";
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1240, 586);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BATTLESHIP";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button00;
        private System.Windows.Forms.Button button01;
        private System.Windows.Forms.Button button02;
        private System.Windows.Forms.Button button03;
        private System.Windows.Forms.Button button04;
        private System.Windows.Forms.Button button05;
        private System.Windows.Forms.Button button06;
        private System.Windows.Forms.Button button07;
        private System.Windows.Forms.Button button08;
        private System.Windows.Forms.Button button09;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button04E;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button00E;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button01E;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button02E;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button03E;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button05E;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button06E;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button07E;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button08E;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button09E;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button10E;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button11E;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button12E;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button13E;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button14E;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button15E;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button16E;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button17E;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button18E;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button button19E;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button20E;
        private System.Windows.Forms.Button button99E;
        private System.Windows.Forms.Button button21E;
        private System.Windows.Forms.Button button98E;
        private System.Windows.Forms.Button button22E;
        private System.Windows.Forms.Button button97E;
        private System.Windows.Forms.Button button23E;
        private System.Windows.Forms.Button button96E;
        private System.Windows.Forms.Button button24E;
        private System.Windows.Forms.Button button95E;
        private System.Windows.Forms.Button button25E;
        private System.Windows.Forms.Button button94E;
        private System.Windows.Forms.Button button26E;
        private System.Windows.Forms.Button button93E;
        private System.Windows.Forms.Button button27E;
        private System.Windows.Forms.Button button92E;
        private System.Windows.Forms.Button button28E;
        private System.Windows.Forms.Button button91E;
        private System.Windows.Forms.Button button29E;
        private System.Windows.Forms.Button button90E;
        private System.Windows.Forms.Button button30E;
        private System.Windows.Forms.Button button89E;
        private System.Windows.Forms.Button button31E;
        private System.Windows.Forms.Button button88E;
        private System.Windows.Forms.Button button32E;
        private System.Windows.Forms.Button button87E;
        private System.Windows.Forms.Button button33E;
        private System.Windows.Forms.Button button86E;
        private System.Windows.Forms.Button button34E;
        private System.Windows.Forms.Button button85E;
        private System.Windows.Forms.Button button35E;
        private System.Windows.Forms.Button button84E;
        private System.Windows.Forms.Button button36E;
        private System.Windows.Forms.Button button83E;
        private System.Windows.Forms.Button button37E;
        private System.Windows.Forms.Button button82E;
        private System.Windows.Forms.Button button38E;
        private System.Windows.Forms.Button button81E;
        private System.Windows.Forms.Button button39E;
        private System.Windows.Forms.Button button80E;
        private System.Windows.Forms.Button button40E;
        private System.Windows.Forms.Button button79E;
        private System.Windows.Forms.Button button41E;
        private System.Windows.Forms.Button button78E;
        private System.Windows.Forms.Button button42E;
        private System.Windows.Forms.Button button77E;
        private System.Windows.Forms.Button button43E;
        private System.Windows.Forms.Button button76E;
        private System.Windows.Forms.Button button44E;
        private System.Windows.Forms.Button button75E;
        private System.Windows.Forms.Button button45E;
        private System.Windows.Forms.Button button74E;
        private System.Windows.Forms.Button button46E;
        private System.Windows.Forms.Button button73E;
        private System.Windows.Forms.Button button47E;
        private System.Windows.Forms.Button button72E;
        private System.Windows.Forms.Button button48E;
        private System.Windows.Forms.Button button71E;
        private System.Windows.Forms.Button button49E;
        private System.Windows.Forms.Button button70E;
        private System.Windows.Forms.Button button50E;
        private System.Windows.Forms.Button button69E;
        private System.Windows.Forms.Button button51E;
        private System.Windows.Forms.Button button68E;
        private System.Windows.Forms.Button button52E;
        private System.Windows.Forms.Button button67E;
        private System.Windows.Forms.Button button53E;
        private System.Windows.Forms.Button button66E;
        private System.Windows.Forms.Button button54E;
        private System.Windows.Forms.Button button65E;
        private System.Windows.Forms.Button button55E;
        private System.Windows.Forms.Button button64E;
        private System.Windows.Forms.Button button56E;
        private System.Windows.Forms.Button button63E;
        private System.Windows.Forms.Button button57E;
        private System.Windows.Forms.Button button62E;
        private System.Windows.Forms.Button button58E;
        private System.Windows.Forms.Button button61E;
        private System.Windows.Forms.Button button59E;
        private System.Windows.Forms.Button button60E;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
    }
}