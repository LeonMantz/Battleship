﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1
{
    internal class SumW
    {
        public int number { get; set; }

        public SumW(int number)
        {
            this.number = number;
        }
    }
}
